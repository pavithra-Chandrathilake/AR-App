package com.example.questionapp;

public class s_proverbLibrary {

    private String mQuestions [] = {
            " දුක් මහන්සියෙන් කළ දෙයක කිසිදු ප්\u200Dරතිඵලයක් නොලැබිම.",
            " එක සමාන ගතිගුණ අදහස් තිබෙන දෙදෙනෙකුගේ එකතුව.",
            " තාමට කළ හැකි යැයි විශ්වාස යමක් කිරිමට ගොස් එය කළ නොහැකි විම.",
            " සුදුසු නුසුදුසු දේ පිළිබද ව නොතකා යමක් කිරිමෙන් විපාක විදිම.",
            "අදූරදර්ශි ලෙස ලබාදෙන උපදෙස් "

    };


    private String mChoices [][] = {
            {"රයිගමයයි ගම්පළයයි වාගේ. ", "ගගට ඉනි කැපුවා වාගේ", "කට නිසා ඉබ්බා නැහුණා වාගේ."},
            {"ගගට ඉනි කැපුවා වාගේ", "රයිගමයයි ගම්පළයයි වාගේ.", "කට නිසා ඉබ්බා නැහුණා වාගේ."},
            {"කට නිසා ඉබ්බා නැහුණා වාගේ.", "ගගට ඉනි කැපුවා වාගේ ", "නරියා මිදි තිත්තයි කිව්වා වාගේ."},
            {"ගගට ඉනි කැපුවා වාගේ ", "නරියා මිදි තිත්තයි කිව්වා වාගේ.", "කට නිසා ඉබ්බා නැහුණා වාගේ."},
            {"මහාදැණ මුත්තාගේ නුවණ වාගේ.", "කට නිසා ඉබ්බා නැහුණා වාගේ.", "නරියා මිදි තිත්තයි කිව්වා වාගේ."}
    };



    private String mCorrectAnswers[] = {"ගගට ඉනි කැපුවා වාගේ", "රයිගමයයි ගම්පළයයි වාගේ.", "නරියා මිදි තිත්තයි කිව්වා වාගේ.", "කට නිසා ඉබ්බා නැහුණා වාගේ.","මහාදැණ මුත්තාගේ නුවණ වාගේ."};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }



}
