package com.example.questionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class mainHome extends AppCompatActivity {

    public Button english;
    public Button sinhala;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main_home);

        english = (Button) findViewById(R.id.english);
        english.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mainHome.this,home1.class);
                startActivity(intent);
            }
        });

        sinhala = (Button) findViewById(R.id.sinhala);
        sinhala.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(mainHome.this,sinhala_home.class);
                startActivity(intent);
            }
        });


    }
}
