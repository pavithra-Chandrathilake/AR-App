package com.example.questionapp;

public class s_synonymLibrary {

    private String mQuestions [] = {
            "පහත වචනයට සමාන පදයක් නොවන්නෙ කුමක්ද?  'මව '",
            "පහත වචනයට සමාන පදයක් වන්නෙ කුමක්ද?  ' ගස ' ",
            "පහත වචනයට සමාන පදයක් නොවන්නෙ කුමක්ද?  'උදව්ව '",
            " පහත වචනයට සමාන පදයක් නොවන්නෙ කුමක්ද?  'යහළුවා' ",
            " පහත වචනයට සමාන පදයක් වන්නෙ කුමක්ද?  'අලුත්' "

    };


    private String mChoices [][] = {
            {" අම්මා ", " ජනනි ", " පියා "},
            {" තුරු ", " තාරකා ", " දිනිදු "},
            {" උපකාරය ", " පිහිය ", " සරණ "},
            {" සකි ", " සබද ", " දිලිදු "},
            {" පරණ ", " නවීන ", " කිලිටු "}
    };



    private String mCorrectAnswers[] = {" පියා ", " තුරු ", " පිහිය ", " දිලිදු "," නවීන "};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }

}
