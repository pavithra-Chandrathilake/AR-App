package com.example.questionapp;

public class s_verbLibrary {

    private String mQuestions [] = {
            "'ළමයි සරුංගල් යවති.' මෙහි 'යවති' යනු ",
            "'තාත්තා ගාල්ලේ ගියේය.' මෙහි 'ගියේය' යනු",
            "'බළලා මීයන්..........' හිස්තැනට සුදුසු වර්තමාන කාල ක්\u200Dරියා පදය වන්නේ,",
            "'අපි පන්සල්...........' හිස්තැනට සුදුසු අනාගත කාල ක්\u200Dරියා පදය වන්නේ,",
            "මෙහි බහුවචන වර්තමාන කාල ක්\u200Dරියා පදය සහිත වාකය කුමක්ද?"

    };


    private String mChoices [][] = {
            {"වර්තමාන කාල ක්\u200Dරියා පදයකි.", "අතීත කාල ක්\u200Dරියා පදයකි.", "අනාගත කාල ක්\u200Dරියා පදයකි."},
            {"අනාගත කාල ක්\u200Dරියා පදයකි.", "වර්තමාන කාල ක්\u200Dරියා පදයකි.", "අතීත කාල ක්\u200Dරියා පදයකි."},
            {"අල්ලයි", "ඇල්ලුවේය.", "අල්ලති"},
            {"ගියෙමු.", "යමු.", "යන්නේමු."},
            {"ගුරුවරු ප්\u200Dරශ්න පත්\u200Dර සකස් කරති.", "ගස් සුළගට සෙලවෙයි.", "අම්මා බත් උයති."}
    };



    private String mCorrectAnswers[] = {"වර්තමාන කාල ක්\u200Dරියා පදයකි.", "අතීත කාල ක්\u200Dරියා පදයකි.", "අල්ලයි", "යන්නේමු.","ගුරුවරු ප්\u200Dරශ්න පත්\u200Dර සකස් කරති."};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }




}
