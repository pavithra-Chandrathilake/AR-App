package com.example.questionapp;

public class QuestionLibrary_verb {

    private String mQuestions [] = {
            "What is the tense of this highlighted word?  'The scientist COLLECTED data on the tree kangaroo.' ",
            "A verb is the STATE OF BEING OR ACTION of the sentence. ",
            "In the sentence below, what is the verb? 'We walked down the street.' ",
            " Identify the verb in the following sentence: 'That woman is a teacher.'",
            " What is the action verb in this sentence?  After the speech, Malika asked a question of sydney."

    };


    private String mChoices [][] = {
            {"Present", "Past", "Future"},
            {"True", "False", "Both"},
            {"We", "Street", "Walked"},
            {"That", "Is", "Teacher"},
            {"Speech", "Question", "Asked"}
    };



    private String mCorrectAnswers[] = {"Past", "True", "Walked", "Is","Asked"};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }


}
