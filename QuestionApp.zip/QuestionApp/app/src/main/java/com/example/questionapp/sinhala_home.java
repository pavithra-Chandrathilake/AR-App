package com.example.questionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.graphics.Typeface;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;


public class sinhala_home extends AppCompatActivity {

    public Button noun1;
    public Button synonym1;
    public Button antonym1;
    public Button proverb1;
    public Button verb1;
    public Button home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sinhala_home);
// link to main sinhala interface

        noun1 = (Button) findViewById(R.id.noun1);
        noun1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sinhala_home.this,s_noun.class);
                startActivity(intent);
            }
        });



        synonym1 = (Button) findViewById(R.id.synonym1);
        synonym1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sinhala_home.this,s_synonym.class);
                startActivity(intent);
            }
        });

        antonym1 = (Button) findViewById(R.id.antonym1);
        antonym1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sinhala_home.this,s_antonym.class);
                startActivity(intent);
            }
        });

        proverb1 = (Button) findViewById(R.id.proverb1);
        proverb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sinhala_home.this,s_proverb.class);
                startActivity(intent);
            }
        });

        verb1 = (Button) findViewById(R.id.verb1);
        verb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sinhala_home.this,s_verb.class);
                startActivity(intent);
            }
        });

        home = (Button) findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(sinhala_home.this,mainHome.class);
                startActivity(intent);
            }
        });






        //start sinhala font
        TextView txt = (TextView) findViewById(R.id.noun1);
        Typeface font = Typeface.createFromAsset(getAssets(), "FM - Samantha x.TTF");
        txt.setTypeface(font);

        TextView txt1 = (TextView) findViewById(R.id.text1);
        Typeface font1 = Typeface.createFromAsset(getAssets(), "FM - Samantha x.TTF");
        txt1.setTypeface(font1);

        TextView txto = (TextView) findViewById(R.id.texto);
        Typeface font2 = Typeface.createFromAsset(getAssets(), "FM - Samantha x.TTF");
        txto.setTypeface(font2);

        TextView txt2 = (TextView) findViewById(R.id.verb1);
        Typeface font3 = Typeface.createFromAsset(getAssets(), "FM - Samantha x.TTF");
        txt2.setTypeface(font3);

        TextView txt3 = (TextView) findViewById(R.id.proverb1);
        Typeface font4 = Typeface.createFromAsset(getAssets(), "FM - Samantha x.TTF");
        txt3.setTypeface(font4);

        TextView txt4 = (TextView) findViewById(R.id.synonym1);
        Typeface font5 = Typeface.createFromAsset(getAssets(), "FM - Samantha x.TTF");
        txt4.setTypeface(font5);

        TextView txt5 = (TextView) findViewById(R.id.antonym1);
        Typeface font6 = Typeface.createFromAsset(getAssets(), "FM - Samantha x.TTF");
        txt5.setTypeface(font6);

        //TextView txt6 = (TextView) findViewById(R.id.verb1);
        //Typeface font7 = Typeface.createFromAsset(getAssets(), "FM - Samantha x.TTF");
       // txt6.setTypeface(font7);
    }
}
