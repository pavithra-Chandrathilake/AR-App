package com.example.questionapp;

public class s_nounLibrary {
    private String mQuestions [] = {
            "මේ අතරින් නාම පදයක් නොවන්නේ කුමක්ද? ",
            "'කුරුල්ලා යනු,'",
            "මේ අතරින් ස්ත්\u200Dරි ලිංග නාම පදයක් වන්නේ, ",
            "'අමර යනු'",
            "මේ අතරින් අප්\u200Dරණවාචි නාම පදයක් වන්නේ,"

    };


    private String mChoices [][] = {
            {"පොත", "කුරුල්ලා", "බලනවා"},
            {"ප්\u200Dරණවාචි නාම පදයකි", "අප්\u200Dරණවාචි නාම පදයකි", "පුද්ගල නාමයකි"},
            {"බල්ලා", "සෙබඩ", "පරවියා"},
            {"පුද්ගල නාමයකි", "ද්\u200Dරවය නාමයකි", "ස්ථාන නාමයකි"},
            {"කතුර", "නයා", "අම්මා"}
    };



    private String mCorrectAnswers[] = {"බලනවා", "ප්\u200Dරණවාචි නාම පදයකි", "සෙබඩ", "පුද්ගල නාමයකි","කතුර"};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }

}
