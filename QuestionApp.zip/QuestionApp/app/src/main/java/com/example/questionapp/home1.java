package com.example.questionapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.Button;
import android.content.Intent;
import android.view.View;
public class home1 extends AppCompatActivity {

    public Button noun;
    public Button proverb;
    public Button verb;
    public Button synonym;
    public Button antonym;
    public Button home;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home1);

        noun = (Button) findViewById(R.id.noun);
        noun.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home1.this,MainActivity.class);
                startActivity(intent);
            }
        });

        proverb = (Button) findViewById(R.id.proverb);
        proverb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home1.this,proverb.class);
                startActivity(intent);
            }
        });

        verb = (Button) findViewById(R.id.verb);
        verb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home1.this,verb.class);
                startActivity(intent);
            }
        });

        synonym = (Button) findViewById(R.id.synonym);
        synonym.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home1.this,synonym.class);
                startActivity(intent);
            }
        });

        antonym = (Button) findViewById(R.id.antonym);
        antonym.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home1.this,antonym.class);
                startActivity(intent);
            }
        });


        home = (Button) findViewById(R.id.home);
        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(home1.this,mainHome.class);
                startActivity(intent);
            }
        });

    }
}
