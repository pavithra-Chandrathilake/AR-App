package com.example.questionapp;

public class QuestionLibrary {
    private String mQuestions [] = {
            "Select the correct answer which is suitable for given noun type?  PLACE ",
            "Which word is NOT a proper noun?",
            "Select the COLLECTIVE noun in this sentence.  'A Flock of birds flew into the sunset.' ",
            "Identify the COMMON noun in this sentence.   'The class studied english leasson today.'",
            "In the sentence below,what type of noun is the word library? 'Amal always studies in the library'"

    };


    private String mChoices [][] = {
            {"Cat", "Bed", "Kandy"},
            {"Mr.Silva", "Boy", "Kandy"},
            {"Flew", "Sunset", "Flock of birds"},
            {"Class", "Today", "English leasson"},
            {"Common", "Collective", "Abstract"}
    };



    private String mCorrectAnswers[] = {"Kandy", "Boy", "Flock of birds", "Class","Common"};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }

}
