package com.example.questionapp;

public class QuestionLibrary_antonym {

    private String mQuestions [] = {
            " A antonym for HAPPY is..........",
            "A antonym for CLOSE is.......... ",
            "A antonym for RICH is.......... ",
            "A antonym for LITTLE is.......... ",
            "A antonym for OFF is.......... "

    };


    private String mChoices [][] = {
            {"ENJOY", "SAD", "GOOD"},
            {"OPEN", "END", "DISCONNECT"},
            {"INCREASE", "WEALTH", "POOR"},
            {"BIG", "SMALL", "LIMIT"},
            {"OUT", "ON", "STOP"}
    };



    private String mCorrectAnswers[] = {"SAD", "OPEN", "POOR", "BIG","ON"};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }


}
