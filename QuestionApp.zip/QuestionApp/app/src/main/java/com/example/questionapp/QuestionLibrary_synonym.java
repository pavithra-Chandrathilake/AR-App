package com.example.questionapp;

public class QuestionLibrary_synonym {

    private String mQuestions [] = {
            "A synonym for ARGUE is.......... ",
            "A synonym for SOLUTION is.......... ",
            "A synonym for END is.......... ",
            "A synonym for IMPORTANT is.......... ",
            "A synonym for VISIBLE is.......... "

    };


    private String mChoices [][] = {
            {"Delightful", "Dissimilar", "Disagree"},
            {"Affirmative", "Ask", "Answer"},
            {"Stop", "Continue", "Do"},
            {"Significant", "Message", "Adjusted"},
            {"Invisible", "Viewable", "Hidden"}
    };



    private String mCorrectAnswers[] = {"Disagree", "Answer", "Stop", "Significant","Viewable"};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }


}
