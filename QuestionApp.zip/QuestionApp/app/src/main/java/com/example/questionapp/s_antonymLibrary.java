package com.example.questionapp;

public class s_antonymLibrary {

    private String mQuestions [] = {
            " පහත සදහන් වචනයට විරුද්ද පදයක් වන්නේ කුමක්ද? 'දේශිය' ",
            " පහත සදහන් වචනයට විරුද්ද පදයක් වන්නේ කුමක්ද? 'පිරිසිදු ' ",
            "පහත සදහන් වචනයට විරුද්ද පදයක් වන්නේ කුමක්ද? 'ප්\u200Dරසිද්ධ ' ",
            " පහත සදහන් වචනයට විරුද්ද පදයක් වන්නේ කුමක්ද? 'සමාන' ",
            " පහත සදහන් වචනයට විරුද්ද පදයක් වන්නේ කුමක්ද? 'හොද' "

    };


    private String mChoices [][] = {
            {" රට තුල ", " මේරට ", " විදේශිය "},
            {" නැවුම් ", " අලුත් ", " අපිරිසිදු "},
            {" අප්\u200Dරසිද්ධ ", " ප්\u200Dරචලිත ", " ප්\u200Dරකට "},
            {" සම ", " අසමාන ", " අසම "},
            {" ගුණ ", " නරක ", " අලස "}
    };



    private String mCorrectAnswers[] = {" විදේශිය ", " අපිරිසිදු ", " අප්\u200Dරසිද්ධ ", " අසමාන "," නරක "};




    public String getQuestion(int a) {
        String question = mQuestions[a];
        return question;
    }


    public String getChoice1(int a) {
        String choice0 = mChoices[a][0];
        return choice0;
    }


    public String getChoice2(int a) {
        String choice1 = mChoices[a][1];
        return choice1;
    }

    public String getChoice3(int a) {
        String choice2 = mChoices[a][2];
        return choice2;
    }

    public String getCorrectAnswer(int a) {
        String answer = mCorrectAnswers[a];
        return answer;
    }


}
